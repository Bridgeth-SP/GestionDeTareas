@file:OptIn(ExperimentalComposeUiApi::class, ExperimentalMaterial3Api::class,
    ExperimentalComposeUiApi::class
)
package com.example.gestiontareas

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.gestiontareas.ui.theme.GestionTareasTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.text.style.TextAlign
import java.time.format.TextStyle

val Context.dataStore by preferencesDataStore(name = "preferencias")

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                VistaPrincipal()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VistaPrincipal() {
    var textoFormulario by remember { mutableStateOf("") }
    var descripcionFormulario by remember { mutableStateOf("") }
    var notasGuardadas by remember { mutableStateOf(emptyList<Pair<String, String>>()) }
    val dataStore = LocalContext.current.dataStore
    val controladorTeclado = LocalSoftwareKeyboardController.current
    var mostrandoFormulario by remember { mutableStateOf(false) }

    LaunchedEffect(key1 = true) {
        notasGuardadas = leerNotas(dataStore)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = "Gestión De Tareas",
                        color = Color.White
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = Color.Magenta,
                    titleContentColor = Color.White
                ),
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { mostrandoFormulario = true }
            ) {
                Icon(Icons.Default.Add, contentDescription = "Agregar tarea")
            }
        },
        bottomBar = {
            BottomAppBar(
                containerColor = Color.LightGray,
                contentColor = Color.White,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                    text = "Notas",
                    color = Color.White
                )
            }
        },
        content = { innerPadding ->
            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .padding(16.dp)
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {
                if (mostrandoFormulario) {
                    Formulario(
                        textoFormulario = textoFormulario,
                        descripcionFormulario = descripcionFormulario,
                        onTextoFormularioChange = { textoFormulario = it },
                        onDescripcionFormularioChange = { descripcionFormulario = it },
                        onGuardarClick = {
                            controladorTeclado?.hide()
                            if (textoFormulario.isNotBlank()) {
                                val nota = Pair(textoFormulario, descripcionFormulario)
                                notasGuardadas = notasGuardadas + nota
                                runBlocking {
                                    guardarNotas(dataStore, notasGuardadas)
                                }
                                textoFormulario = ""
                                descripcionFormulario = ""
                                mostrandoFormulario = false
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn {
                    items(notasGuardadas.size) { index ->
                        val nota = notasGuardadas[index]
                        NotaItem(
                            nota = nota,
                            onDelete = {
                                notasGuardadas = notasGuardadas.toMutableList().apply {
                                    remove(nota)
                                }
                                runBlocking {
                                    guardarNotas(dataStore, notasGuardadas)
                                }
                            }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    )
}

@Composable
fun Formulario(
    textoFormulario: String,
    descripcionFormulario: String,
    onTextoFormularioChange: (String) -> Unit,
    onDescripcionFormularioChange: (String) -> Unit,
    onGuardarClick: () -> Unit
) {
    Column {
        OutlinedTextField(
            value = textoFormulario,
            onValueChange = { onTextoFormularioChange(it) },
            label = { Text("Título") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        OutlinedTextField(
            value = descripcionFormulario,
            onValueChange = { onDescripcionFormularioChange(it) },
            label = { Text("Descripción") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = onGuardarClick) {
            Text("Guardar")
        }
    }
}

@Composable
fun NotaItem(nota: Pair<String, String>, onDelete: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(text = "Título: ${nota.first}")
            Text(text = "Descripción: ${nota.second}")
        }
        Spacer(modifier = Modifier.width(16.dp))
        IconButton(onClick = onDelete) {
            Icon(Icons.Default.Delete, contentDescription = "Eliminar nota")
        }
    }
}

suspend fun guardarNotas(dataStore: DataStore<Preferences>, notas: List<Pair<String, String>>) {
    val clave = stringPreferencesKey("notas")
    val notasString = notas.joinToString(separator = ";") { "${it.first},${it.second}" }
    dataStore.edit { preferences ->
        preferences[clave] = notasString
    }
}

suspend fun leerNotas(dataStore: DataStore<Preferences>): List<Pair<String, String>> {
    val dataStoreKey = stringPreferencesKey("notas")
    val preferences = dataStore.data.first()
    val notasString = preferences[dataStoreKey]
    return notasString?.split(";")?.map {
        val partes = it.split(",")
        Pair(partes[0], partes[1])
    } ?: emptyList()
}